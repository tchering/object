<?php
const host="localhost";
const dbname="form";
const user="admin";
const password="Ilovedopeleaf1.";
?>